#include<stdio.h>
#include <stdlib.h>
#include "game.h"
void findPlayerPosition(char** Grid,int*mapRow,int*mapCol,int *x,int *y)
{
int i;
int j;

for(i=0;i<*mapRow;i++)
{
for(j=0;j<*mapCol;j++)
{ 
if(Grid[i][j] =='^'|| Grid[i][j] =='v' || Grid[i][j] =='<' || Grid[i][j] =='>')
{
*x=i;
*y=j;
/*printf("The player postion is: [%d] [%d]",i,j );*/
/*printf("\n");*/ 
}
   


}
}
}

void MovePlayer(char** Grid,int*mapRow,int*mapCol,int *x,int *y)
{

 char a;
 scanf("%c",&a);
 printf(" ");
 if(a=='a' && Grid[*x][*y-1]!='o'  && Grid[*x][*y-1]!='|' )
 {
  Grid[*x][*y]=' ';
 *y=*y-1;
 Grid[*x][*y]='<';
 }
 else if(a=='w' && Grid[*x-1][*y]!='o'  && Grid[*x-1][*y]!='-')
 {
  Grid[*x][*y]=' ';
  
   *x=*x-1;
  Grid[*x][*y]='^';

 }
 else if(a=='d' && Grid[*x][*y+1]!='o'  && Grid[*x][*y+1]!='|')
 {
  Grid[*x][*y]=' ';
 *y=*y+1;
 Grid[*x][*y]='>';
 }
 else if(a=='s' && Grid[*x+1][*y]!='o'  && Grid[*x+1][*y]!='-')
 {
  Grid[*x][*y]=' ';
 *x=*x+1;
 Grid[*x][*y]='v';
 }
 else
 {
 
 

 }
 
 
} 

void findTreasure(char** Grid,int*mapRow,int*mapCol,int *x,int *y) 
{
int i;
int j;

for(i=0;i<*mapRow;i++)
{
for(j=0;j<*mapCol;j++)
{ 
if(Grid[i][j] =='x')
{
x=&i;
y=&j;

}
   


}
}
}



