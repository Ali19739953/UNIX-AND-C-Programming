#ifndef LINKEDLIST_H
#define LINKEDLIST_H
void InsertatStart(int data);
int getSize();
int DeletefromStart();
int DeleteFromend();
#endif
