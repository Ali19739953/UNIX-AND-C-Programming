#ifndef DISPLAY_H
#define DISPLAY_H
void display(char **Grid, int row, int col);
void allocate_display_grid(char **Grid, int row, int col);
void display_numpad(char **numpad, int num_padrows, int num_padcols);

int ConvertGrid_Int(char** Grid);
#endif
