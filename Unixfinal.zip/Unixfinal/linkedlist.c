#include<stddef.h>
#include <stdio.h>
#include <stdlib.h>




struct LinkedListNode

{
 int data;
 struct LinkedListNode * next;
};


struct LinkedListNode *Head=NULL;



void InsertatStart(int data) 
{

        struct LinkedListNode *temp;

        temp=(struct LinkedListNode *)malloc(sizeof(struct LinkedListNode));
    
     
        
       temp->data=data;
	
        temp->next =NULL;
        if(Head==NULL)
        {
                Head=temp;
        }
        else
        {
                temp->next=Head;   
                Head=temp;   
        }
}

int DeletefromStart()  
{
        int d;
    
        struct LinkedListNode *ptr;
        if(Head==NULL)
        {
                printf("\nList is Empty:\n");
                return -1;
        }
        
        else
        {
                ptr=Head;
                Head=Head->next ;
              
               d=ptr->data;
                free(ptr);
                return d;
        }
        return -1;
}

int getSize()
{
 struct LinkedListNode *ptr=Head;
 
 int size=0;
  if(Head==NULL)
  {
  return 0;
  }
 while(ptr->next!=NULL)
 {
 ptr=ptr->next;
 size++;
 }
 
 return size;

}

int DeleteFromend()
{
int d;
   struct LinkedListNode *temp,*ptr;
        if(Head==NULL)
        {
                
                exit(0);
        }
        else if(Head->next ==NULL)
        {
                ptr=Head;
                Head=NULL;
                 d=ptr->data;
                
                free(ptr);
                return d;
        }
        else
        {
                ptr=Head;
                while(ptr->next!=NULL)
                {
                        temp=ptr;
                        ptr=ptr->next;
                }
                
                temp->next=NULL;
                 d=ptr->data;
                
                free(ptr);
                return d;
        }
        
        
}




