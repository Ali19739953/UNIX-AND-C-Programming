#include<stdio.h>
#include <stdlib.h>
#include "map.h"
#include "init.h" /*Contains Grid Initialization*/
#include "game.h"  /*Contains Game working Methods*/







int main(int argc,char *argv[])
{
    int mapRow;
    int mapCol;
    int metadataAmount;
    int x;
    int i;
    int y;
    int v;
    int w;
    int** Grid;  
    char **Ugrid; /*holds the grid*/
    int Game=-1;
    int visibility=0;
    visibility=atoi(argv[1]);
    if(argc<0 && argc>2)
    {
    return 0;
    }
    if(visibility>2)
    {
    printf("Enter the size between 0 to 2\n");
   
    return 0;
    }
   
    
    
     
    
    getMetadata(&Grid,&metadataAmount,&mapRow,&mapCol);
    /*grid is now populated*/
    Convert_Int_to_Char(Grid,&Ugrid,&metadataAmount,&mapRow,&mapCol);
   findPlayerPosition(Ugrid,&mapRow,&mapRow,&x,&y);
   findTreasure(Ugrid,&mapRow,&mapRow,&v,&w);/*function to find goal*/
   v=1;w=8; /*goal Coordinates*/
  
   while(Game==-1)
   {
    
    displayC(Ugrid,&mapRow,&mapCol,&x,&y,visibility);
    if(x==v && w==y)
    {
    Game=1; /*won game;*/
    }
     
    MovePlayer(Ugrid,&mapRow,&mapCol,&x,&y);
    
   
   }
   printf("\n\nYou have won the Game\n\n");
   
   
/*Grid Free after Player Won*/ 
  
for(i=0; i < mapRow; i++){
    free(Ugrid[i]);
    }
   free(Ugrid);

   return 0;
}



