#ifndef INIT_H
#define INIT_H
void saveToFIle(char *filename,double currentTotal);
void ChangeGrid(char **numpad);
void disableBuffer();

void enableBuffer();
#endif
