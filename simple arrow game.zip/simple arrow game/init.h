void Convert_Int_to_Char(int **Grid,char ***table,int * metadataAmount,int * mapRow, int * mapCol); /*fetch information from metatable and place object accordingly*/
void display(int** Grid,int*mapRow,int*mapCol); /*prints metadata table*/
void displayC(char** Grid,int*mapRow,int*mapCol,int *x,int *y,int v); /*prints the grid*/
