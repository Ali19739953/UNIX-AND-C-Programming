void MovePlayer(char** Grid,int*mapRow,int*mapCol,int *x,int *y);/*Move Player and Update Grid Moving*/

void findPlayerPosition(char** Grid,int*mapRow,int*mapCol,int *x,int *y);
void findTreasure(char** Grid,int*mapRow,int*mapCol,int *x,int *y);
