#include <stdio.h>
#include <stdlib.h>
#include<termios.h>
#include<time.h>
#include "linkedlist.h"
void saveToFIle(char *filename,double currentTotal)/*File handling*/
{
int d=0;
int i=0;
int a=currentTotal;
FILE *f;
f=fopen(filename,"w");

if(f==NULL)
{

 
}
else
{

for(i=0;i<getSize();i++)
{
  putc('(',f);
}

d= DeleteFromend(); /*initial value*/
fprintf(f,"%d",d); 

d= DeleteFromend(); 
while(d!=-1)
{
 putc('/',f);
fprintf(f,"%d",d);
 putc(')',f);
 if(getSize()==0)
 {
 putc('=',f);
fprintf(f,"%d",a);
 }
d= DeleteFromend();

}


fclose(f);

}



}
void ChangeGrid(char **numpad)/*Random function*/
{
 int k;
 int l;
 int i=0;
 int j=0;
 int count=0;
 int arr[4]={0,2,4,6};

 srand( time(0));  
 for(i=0;i<8;i++)
 {
 for(j=0;j<3;j++)
 {
 numpad[i][j]=' ';
 }
 }
 
numpad[1][1]='^';
 k=0 + (rand() % (5-0));
 l=0 + (rand() % (3-0));

 numpad[arr[k]][l]='=';

 k=0 + (rand() % (5-0));
 l=0 + (rand() % (3-0));
while(numpad[arr[k]][l]!=' ')
{
 k=rand() % 9;
 l=rand() % 4;
} 
 numpad[arr[k]][l]='/';
 
 



 for(i=0;i<10;i++)
 {

 {
  k=0 + (rand() % (5-0));
 l=0 + (rand() % (3-0));

while(numpad[arr[k]][l]!=' ')
{

 k=0 + (rand() % (5-0));
 l=0 + (rand() % (3-0));
}
numpad[arr[k]][l]=count+'0';
count++;
 }
 }
 
 
  
}



void disableBuffer()
{
    struct termios mode;

    tcgetattr(0, &mode);
    mode.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(0, TCSANOW, &mode);
}

void enableBuffer()
{
    struct termios mode;

    tcgetattr(0, &mode);
    mode.c_lflag |= (ECHO | ICANON);
    tcsetattr(0, TCSANOW, &mode);
}
