#ifndef ARROW_H
#define ARROW_H
void Find_Arrow(char **numpad, int num_padrows, int num_padcols, int *x, int *y);
void Move_Arrow(char **Grid, char **numpad, int num_padrows, int num_padcols, int *x, int *y,double *currentTotal,int *run,char *filename);
#endif
