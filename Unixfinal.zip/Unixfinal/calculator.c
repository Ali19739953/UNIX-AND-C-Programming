#include <stdio.h>
#include <stdlib.h>
#include<termios.h>
#include<time.h>
#include"init.h"/*Contains Grid Initialization*/
#include "linkedlist.h"/*linkedlist*/
#include "arrow.h"/*Contains Arrow functionality*/
#include "display.h"/*Contains display functionality*/



int main(int argc, char *argv[])
{
   
    int run=0;
    int x;
    int y;
    int num_padrows = 8;/*Numpad rows*/
    int num_padcols = 3;/*Numpad cols*/
    char **numpad = NULL;/*declare 2D array*/
    int row = 3;/*Grid Rows*/
    int col = 9;/*Grid cols*/
    char **Grid = NULL; /*declare 2D array*/
    int i, j;
    double currentTotal=0;
       if(argc !=3)/*if commandline parameters are less than three it will print a message*/
	{
	printf("Please Provide argument Correctly : <filename> <initial_number>\n");

	return(-1);
	}
    currentTotal=atoi(argv[2]);
    
     InsertatStart(currentTotal);/*linked lsit function call*/
    Grid = (char **)malloc(sizeof(char *) * row);
    for (i = 0; i < row; i++)
    {
        Grid[i] = (char *)malloc(sizeof(char) * col);
    }

    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            Grid[i][j] = ' ';
        }
    }
    /* This is to create the borders and hold '0' in 7th col(populate)*/
    for( i=0;i<9;i++)
    {
      Grid[0][i]='-';
    }
    for( i=0;i<9;i++)
    {
      Grid[2][i]='-';
    }
    
    Grid[1][0] = '|';
    
    Grid[1][7] = '0';
    Grid[1][8] = '|';

    printf("\n");

    numpad = (char **)malloc(sizeof(char *) * num_padrows);
    for (i = 0; i < num_padrows; i++)
    {
        numpad[i] = (char *)malloc(sizeof(char) * num_padcols);
    }

    for (i = 0; i < num_padrows; i++)
    {
        for (j = 0; j < num_padcols; j++)
        {
            numpad[i][j] = ' ';
        }
    }

    numpad[0][0] = '5';/*to populate the numpad */
    numpad[0][1] = '0';
    numpad[0][2] = '6';
    numpad[1][0] = '^';
    numpad[2][0] = '=';
    numpad[2][1] = '8';
    numpad[2][2] = '7';
    numpad[4][0] = '2';
    numpad[4][1] = '1';
    numpad[4][2] = '9';
    numpad[6][0] = '3';
    numpad[6][1] = '4';
    numpad[6][2] = '/';

    Find_Arrow(numpad, num_padrows, num_padcols, &x, &y);/*Funtion call */
    disableBuffer();/*Funtion call */
    while (run==0)
    {
        system("clear");/*clear screen*/
        Find_Arrow(numpad, num_padrows, num_padcols, &x, &y);/*Funtion call */
        display(Grid, row, col);/*Funtion call */
        display_numpad(numpad, num_padrows, num_padcols);/*Funtion call */
        printf("Current Total : %.2f\n", currentTotal);
       
        Move_Arrow(Grid, numpad, num_padrows, num_padcols, &x, &y, &currentTotal,&run,argv[1]);/*Funtion call */
        
    }
    
    
    
    enableBuffer();
    for(i=0; i < 8; i++){
    free(numpad[i]);
    }
   free(numpad);
   for(i=0; i < 3; i++){
    free(Grid[i]);
    }
   free(Grid);
    return 0;
}


