#ifndef MAP_H
#define MAP_H

void getMetadata(int *** metadataTable, int * metadataAmount, int * mapRow, int * mapCol);

#endif