#include<stdlib.h>
#include <stdio.h>
#include "init.h"
void Convert_Int_to_Char(int **Grid,char ***table,int * metadataAmount,int * mapRow, int * mapCol)
{

    int i=0,j=0,l=0,k=0;

    char ** table2; /*declare array*/

    table2 = (char **) malloc(sizeof(char *) * (*mapRow));  /*how many rows it should have*/

    for(i = 0 ; i < (*mapRow) ; i++)
    {
        table2[i] = (char *) malloc(sizeof(char) * (*mapCol)); /*defines number of colounm in each row*/
    }
   
   

    for(i=0; i<*mapRow; i++)
    {
        for(j=0; j<*mapCol; j++)
        {
            table2[i][j]=' ';
        }

    }


    for(i=0;i<17;i++)
    {

        {

            if(i==0)
            {

                k=Grid[i][0];

                l=Grid[i][1];

                table2[k][l]='^';


            }
            else if(i==1)
            {

                k=Grid[i][0];

                l=Grid[i][1];

                table2[k][l]='x';

            }
            else
            {
               k=Grid[i][0];
                l=Grid[i][1];
                table2[k][l]='o';
            }

        }
       
    }
   
     table2[0][0]='#';
      table2[0][1]='-';
      table2[0][2]='-';
      table2[0][3]='-';
      table2[0][4]='-';
      table2[0][5]='-';
      table2[0][6]='-';
      table2[0][7]='-';
      table2[0][8]='-';
      table2[0][9]='#';
      table2[1][0]='|';
      table2[2][0]='|';
      table2[3][0]='|';
      table2[4][0]='|';
      table2[5][0]='|';
      table2[6][0]='|';
      table2[7][0]='#';
      table2[7][1]='-';
      table2[7][2]='-';
      table2[7][3]='-';
      table2[7][4]='-';
      table2[7][5]='-';
      table2[7][6]='-';
      table2[7][7]='-';
      table2[7][8]='-';
      table2[7][9]='#';
      table2[6][9]='|';
      table2[5][9]='|';
      table2[4][9]='|';
      table2[3][9]='|';
      table2[2][9]='|';
      table2[1][9]='|';
  
      
      
     
     
     
      
      
      
      
      
    *table=table2; /*save Result*/
     
      
            
    
  /*Free memory of metaData*/  
   
for(i=0; i < *mapRow; i++)
    free(Grid[i]);
free(Grid);


}
void display(int** Grid,int*mapRow,int*mapCol)
{

    int i=0,j=0;
    for(i=0; i<17; i++)
    {
        for(j=0; j<3; j++)
        {
            printf(" %d",Grid[i][j]);
        }
        printf("\n");
    }
}
int i,j;
void displayC(char** Grid,int*mapRow,int*mapCol,int *x,int *y,int v)
{
    system("clear");  /*clear screen*/
    
    for(i=0; i<*mapRow; i++)
    {
        for(j=0; j<*mapCol; j++)
        { 
        if(v!=0)
        {
           if(i-*x<=v && i-*x>=0 && j-*y<=v && j-*y>=0 )
            printf("%c",Grid[i][j]);
            else
            {
            printf(" ");
            }
         }
         else
         {
           printf("%c",Grid[i][j]);
            
         
         }
        }
        printf("\n");
    }

}

