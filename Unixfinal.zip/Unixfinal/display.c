
#include <stdio.h>
#include <stdlib.h>
#include<termios.h>
#include<time.h>
#include "linkedlist.h"
#include"init.h"
void display_numpad(char **numpad, int num_padrows, int num_padcols)/*To display the 2d array grid of numpad,(The actual Calculator) */
{
    int i = 0, j = 0;
    for (i = 0; i < num_padrows; i++)
    {
        for (j = 0; j < num_padcols; j++)
        {
            printf(" %c", numpad[i][j]);
        }
        printf("\n");
    }
}

void display(char **Grid, int row, int col)/* To display the 2d array grid of grid,(Where the numbers are to be displayed) */
{

    int i = 0, j = 0;
    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            printf(" %c", Grid[i][j]);
        }
        printf("\n");
    }
}


int ConvertGrid_Int(char** Grid)/*to convert the characters into integers*/
{
int i;
int num =0;
for(i=1;i<=7;i++)
{
	if(Grid[1][i] != ' ')
	{
	num = num*10;
	 num = num + (Grid[1][i]-'0');
	 
	}
}
for(i=1;i<=7;i++)
{
Grid[1][i]=' ';
}
Grid[1][7]='0';
return num;
}



