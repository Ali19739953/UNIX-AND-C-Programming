#!/bin/bash
if [  $# -ne 2 ] ;
then
echo No argument provided!
fi
if grep -nrim $2 $1 data; #'r' is to find data recursivley and 'i' is for it to be case insesitive and m is for max count'n' is to print the line number.
then
echo Success!
else 
echo Notfound! try again
fi

