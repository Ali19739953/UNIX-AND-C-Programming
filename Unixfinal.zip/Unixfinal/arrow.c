#include <stdio.h>
#include <stdlib.h>
#include<termios.h>
#include<time.h>
#include "linkedlist.h"
#include"init.h"
#include "display.h"
void Find_Arrow(char **numpad, int num_padrows, int num_padcols, int *x, int *y)/*To find the arrow on the numpad*/
{

    int i, j;
    for (i = 0; i < num_padrows; i++)
    {
        for (j = 0; j < num_padcols; j++)
        {
            if (numpad[i][j] == '^')
            {
                *x = i;
                *y = j;
                
            }
        }
    }
}
void Move_Arrow(char **Grid, char **numpad, int num_padrows, int num_padcols, int *x, int *y,double *currentTotal,int *run,char *filename)/*To move the arrow on the numpad*/
{
    int k = 0;
    char w;
    scanf("%c", &w);

    if (w == 's' )
    {	 
            
        
   	 if(*x+2>=num_padrows)
   	 {
   	  numpad[*x][*y] = ' ';
   	  *x=1;
   	  numpad[*x][*y] = '^';
   	 }
    	else
    	{   
        numpad[*x][*y] = ' ';
        *x = *x + 2;
        numpad[*x][*y] = '^';
        }
        
    }
    if (w == 'a')
    {
	if(*y+2>=num_padcols)

	{
	
	   numpad[*x][*y] = ' ';
	   *y=*y-1;
	   numpad[*x][*y] ='^';
	   	
	}
	else
	{
		numpad[*x][*y] = ' ';
		*y = *y + 2;
		numpad[*x][*y] = '^';
	}
	
       
    }
       if (w == 'd')
   {
	if(*y+2<=num_padcols)

	{
	
	   numpad[*x][*y] = ' ';
	   *y=*y+1;
	   numpad[*x][*y] ='^';
	   	
	}
	else
	{
		numpad[*x][*y] = ' ';
		*y = *y - 2;
		numpad[*x][*y] = '^';
	}
	
       
    }
    if (w == 'w' )
    {
       if(*x-2<0)
       {
        numpad[*x][*y] = ' ';
        *x=7;
         numpad[*x][*y] = '^';
       }
       else{
        numpad[*x][*y] = ' ';
        *x = *x - 2;
        numpad[*x][*y] = '^';
        }
    }
    if (w == 'e')
    {
        
        /*      0*/
        if (Grid[1][7] == '0' && numpad[*x - 1][*y] >= '0' && numpad[*x - 1][*y] <= '9' && Grid[1][6]==' ')
        {
            Grid[1][7] = numpad[*x - 1][*y];
            
        }

        /*      1*/
        else if (Grid[1][6] == ' ' && numpad[*x - 1][*y] >= '0' && numpad[*x - 1][*y] <= '9')
        {
            Grid[1][6] = Grid[1][7];
            Grid[1][7] = numpad[*x - 1][*y];
        }

        /*  24312*/
        else if (Grid[1][1] == ' ' && numpad[*x - 1][*y] >= '0' && numpad[*x - 1][*y] <= '9')
        {
            for (k = 7; Grid[1][k] != ' '; k--)
            {
            }

            for (; k < 7; k++)
            {
                Grid[1][k] = Grid[1][k + 1];
            }
            Grid[1][7] = numpad[*x - 1][*y];
        }
        else if (numpad[*x-1][*y]=='/')
        {
                int denominator=ConvertGrid_Int(Grid);
        	*currentTotal=*currentTotal / denominator;
        	 InsertatStart(denominator);
        	 
        	
        }
        else if(numpad[*x-1][*y]=='=')
        {
        *run=-1;
        saveToFIle(filename,*currentTotal);
        }
        ChangeGrid(numpad);
    }
}
